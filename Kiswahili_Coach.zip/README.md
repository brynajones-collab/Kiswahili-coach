# Kiswahili Coach (Beginner Web App)

A lightweight, beautiful, and interactive single-page web app to practice beginner Swahili (Kiswahili) with:
- **Flashcards** (tap to flip, spaced-ish streaks, TTS pronunciation if available)
- **Word Matching** (pair Swahili ↔ English)
- **Language Prompts** (guided writing with tips)
- **Progress** (daily activity bars, local persistence)
- **Custom Decks** (add your own terms; import/export JSON)

## Quick start
1. Unzip the folder.
2. Open `index.html` in your browser (Chrome/Edge/Firefox/Safari).
3. Optional: Toggle dark/light theme (moon button).

All data is stored in your browser via `localStorage` — no server needed.

## Customize decks
- Use **＋ Add Term** to add new words to the selected deck.
- Export decks to JSON; import later (or share with a study buddy).

## Notes
- Speech playback uses your browser's voices. If a Swahili voice isn't installed, it will still try to pronounce with default TTS.
- Matching game increments progress when completed.
- This is a clean baseline; you can extend with verbs, tenses, or audio clips.

Karibu kusoma! (Welcome to study!)
// Kiswahili Coach — vanilla JS, localStorage persistence
const qs = (s, el=document)=>el.querySelector(s);
const qsa = (s, el=document)=>[...el.querySelectorAll(s)];

const DEFAULT_DECKS = {
  "Starter • Salamu (Greetings)": [
    {sw:"habari", en:"news/how are you?", ex:"Habari za asubuhi?"},
    {sw:"asante", en:"thank you", ex:"Asante sana!"},
    {sw:"tafadhali", en:"please", ex:"Tafadhali, njoo hapa."},
    {sw:"samahani", en:"sorry/excuse me", ex:"Samahani kwa kuchelewa."},
    {sw:"karibu", en:"welcome/you're welcome", ex:"Karibu nyumbani!"},
    {sw:"pole", en:"sorry (sympathy)", ex:"Pole na kazi."},
    {sw:"ndiyo", en:"yes", ex:"Ndiyo, ninaelewa."},
    {sw:"hapana", en:"no", ex:"Hapana, sihitaji."},
    {sw:"jina langu ni...", en:"my name is...", ex:"Jina langu ni Bryna."},
    {sw:"naitwa...", en:"I am called...", ex:"Naitwa Amina."},
    {sw:"shikamoo", en:"(respectful greeting)", ex:"Shikamoo, Mwalimu."},
    {sw:"marahaba", en:"response to shikamoo", ex:"Marahaba."}
  ],
  "Daily • Msingi (Basics)": [
    {sw:"asubuhi", en:"morning", ex:"Asubuhi njema!"},
    {sw:"mchana", en:"afternoon", ex:"Mchana mwema."},
    {sw:"jioni", en:"evening", ex:"Jioni njema."},
    {sw:"usiku", en:"night", ex:"Usiku mwema."},
    {sw:"ndugu", en:"relative/brother/sister", ex:"Huyu ni ndugu yangu."},
    {sw:"rafiki", en:"friend", ex:"Rafiki yangu anaishi Dar es Salaam."},
    {sw:"chakula", en:"food", ex:"Ninapenda chakula cha Kiswahili."},
    {sw:"maji", en:"water", ex:"Naweza kupata maji?"},
    {sw:"soko", en:"market", ex:"Tunaenda sokoni leo."},
    {sw:"bei", en:"price", ex:"Bei gani?"},
    {sw:"wapi", en:"where", ex:"Choo kiko wapi?"},
    {sw:"kwanini", en:"why", ex:"Kwanini umechelewa?"}
  ],
  "Numbers • Nambari 1–10": [
    {sw:"moja", en:"one", ex:"Nina kalamu moja."},
    {sw:"mbili", en:"two", ex:"Ana watoto wawili."},
    {sw:"tatu", en:"three", ex:"Mitungi mitatu."},
    {sw:"nne", en:"four", ex:"Saa nne."},
    {sw:"tano", en:"five", ex:"Saa tano."},
    {sw:"sita", en:"six", ex:"Viti sita."},
    {sw:"saba", en:"seven", ex:"Siku saba."},
    {sw:"nane", en:"eight", ex:"Miezi minane."},
    {sw:"tisa", en:"nine", ex:"Vitabu tisa."},
    {sw:"kumi", en:"ten", ex:"Kumi na mbili=12."}
  ]
};

const LS_KEY = "kiswahili-coach-v1";
const state = {
  decks: {},
  history: [],     // [{date, correct, seen}]
  streak: 0,
  stats: {seen:0, mastered:0},
  theme: "dark",
};

function loadState(){
  const raw = localStorage.getItem(LS_KEY);
  if(raw){
    try{ Object.assign(state, JSON.parse(raw)); }catch{}
  } else {
    state.decks = DEFAULT_DECKS;
  }
}
function saveState(){ localStorage.setItem(LS_KEY, JSON.stringify(state)); }

function ensureDeckSelection(){
  const sel = qs("#deckSelect");
  sel.innerHTML = "";
  Object.keys(state.decks).forEach(name=>{
    const o = document.createElement("option");
    o.value = name; o.textContent = name;
    sel.appendChild(o);
  });
  if(!sel.value) sel.value = Object.keys(state.decks)[0];
}

let currentDeck = [];
let fcIndex = 0;
let fcFlipped = false;

function initFlashcards(){
  const name = qs("#deckSelect").value;
  currentDeck = [...state.decks[name]];
  // Shuffle
  for(let i=currentDeck.length-1;i>0;i--){
    const j = Math.floor(Math.random()*(i+1));
    [currentDeck[i], currentDeck[j]] = [currentDeck[j], currentDeck[i]];
  }
  fcIndex = 0;
  fcFlipped = false;
  renderFlashcard();
}

function renderFlashcard(){
  const card = qs("#flashcard");
  const term = qs("#fcTerm");
  const def = qs("#fcDef");
  const ex = qs("#fcExample");
  const count = qs("#fcCount");
  const streakEl = qs("#fcStreak");

  const item = currentDeck[fcIndex % currentDeck.length];
  term.textContent = item.sw;
  def.textContent = item.en;
  ex.textContent = item.ex || "";
  count.textContent = `${(fcIndex % currentDeck.length)+1} / ${currentDeck.length}`;
  streakEl.textContent = `Streak: ${state.streak||0}`;
  card.classList.remove("flipped");
  fcFlipped = false;
}

function speakSwahili(text){
  if(!("speechSynthesis" in window)) return alert("Speech not supported in this browser.");
  const u = new SpeechSynthesisUtterance(text);
  // Try Kiswahili voice if available
  const voices = speechSynthesis.getVoices();
  const sw = voices.find(v=>/sw|swahili/i.test(v.lang||""));
  if(sw) u.voice = sw;
  u.lang = sw?.lang || "sw";
  speechSynthesis.cancel();
  speechSynthesis.speak(u);
}

function markAnswer(correct){
  state.stats.seen++;
  const today = new Date().toISOString().slice(0,10);
  const entry = state.history.find(h=>h.date===today) || {date:today, seen:0, correct:0};
  entry.seen += 1;
  if(correct) entry.correct += 1;
  if(!state.history.find(h=>h.date===today)) state.history.push(entry);

  if(correct){
    state.streak += 1;
    // naive mastery: after 3 correct on same loop, count as mastered
    if(state.streak % 3 === 0) state.stats.mastered += 1;
  } else {
    state.streak = 0;
  }
  saveState();
  fcIndex++;
  renderFlashcard();
  drawHistory();
  renderStats();
}

function initMatching(){
  const grid = qs("#matchGrid");
  const pairCount = Math.min(Math.max(parseInt(qs("#pairCount").value)||6,3), 10);
  const name = qs("#deckSelect").value;
  const items = [...state.decks[name]];
  // Shuffle and take pairCount
  for(let i=items.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [items[i],items[j]]=[items[j],items[i]];}
  const sample = items.slice(0, pairCount);
  const cards = [];
  sample.forEach(it=>{
    cards.push({t:it.sw, key:it.sw, type:"sw"});
    cards.push({t:it.en, key:it.sw, type:"en"});
  });
  for(let i=cards.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [cards[i],cards[j]]=[cards[j],cards[i]];}
  grid.innerHTML = "";
  let first = null;
  let solved = 0;
  let sec = 0;
  const timerEl = qs("#matchTimer");
  const timer = setInterval(()=>{
    sec++; const m = String(Math.floor(sec/60)).padStart(2,"0"); const s=String(sec%60).padStart(2,"0");
    timerEl.textContent = `${m}:${s}`;
  }, 1000);

  cards.forEach((c,i)=>{
    const tile = document.createElement("button");
    tile.className = "tile";
    tile.textContent = c.t;
    tile.setAttribute("data-key", c.key);
    tile.setAttribute("aria-pressed","false");
    tile.addEventListener("click", ()=>{
      if(tile.classList.contains("correct")) return;
      tile.classList.remove("wrong");
      tile.setAttribute("aria-pressed","true");
      if(!first){ first = {tile, key:c.key}; tile.classList.add("active"); return; }
      if(first.key === c.key && first.tile !== tile){
        // match
        tile.classList.add("correct"); first.tile.classList.add("correct");
        tile.setAttribute("aria-pressed","false"); first.tile.setAttribute("aria-pressed","false");
        solved += 1;
        first = null;
        if(solved === pairCount){
          clearInterval(timer);
          state.stats.seen += pairCount;
          state.stats.mastered += 1;
          saveState();
          renderStats(); drawHistory();
        }
      } else {
        tile.classList.add("wrong");
        first.tile.classList.add("wrong");
        setTimeout(()=>{
          tile.classList.remove("wrong"); first.tile.classList.remove("wrong");
          tile.setAttribute("aria-pressed","false"); first.tile.setAttribute("aria-pressed","false");
          first = null;
        }, 600);
      }
    });
    grid.appendChild(tile);
  });
}

const PROMPTS = [
  {en:"Introduce yourself to a new friend (2–3 sentences). Use habari/asante/tafadhali.", tips:["habari","naitwa","ninatoka","nafanya kazi"]},
  {en:"Order food and ask for water politely.", tips:["Ningependa...","tafadhali","maji"]},
  {en:"Ask someone where the market is and the price of tomatoes.", tips:["... wapi?","bei gani?"]},
  {en:"Say good morning and ask how someone is doing.", tips:["Asubuhi njema","Habari za leo?"]},
  {en:"Count objects from one to five in Swahili.", tips:["moja","mbili","tatu","nne","tano"]},
];

const CHEATSHEET = [
  ["Habari za asubuhi?","How is your morning?"],
  ["Naitwa ...","My name is ..."],
  ["Ninatoka ...","I come from ..."],
  ["Tafadhali","Please"],
  ["Asante / Asante sana","Thanks / Thank you very much"],
  ["Samahani","Sorry / Excuse me"],
  ["Choo kiko wapi?","Where is the washroom?"],
  ["Bei gani?","What price?"],
  ["Naweza kupata maji?","Can I get water?"],
  ["Habari za leo?","How's your day today?"],
  ["Sawa","Okay"],
  ["Ndiyo / Hapana","Yes / No"],
];

function initPrompts(){
  qs("#cheatGrid").innerHTML = CHEATSHEET.map(([sw,en])=>`<div class="sheet-item"><strong>${sw}</strong><div>${en}</div></div>`).join("");
  shufflePrompt();
}

function shufflePrompt(){
  const p = PROMPTS[Math.floor(Math.random()*PROMPTS.length)];
  qs("#promptText").textContent = p.en;
  qs("#promptInput").value = "";
  qs("#promptFeedback").textContent = "";
  qs("#promptInput").dataset.tips = JSON.stringify(p.tips||[]);
}

function checkPrompt(){
  const text = qs("#promptInput").value.toLowerCase();
  const tips = JSON.parse(qs("#promptInput").dataset.tips||"[]");
  let score = 0;
  tips.forEach(t=>{ if(text.includes(t)) score++; });
  let fb = `Nice! You used ${score}/${tips.length} target words.`;
  if(score < Math.ceil(tips.length/2)) fb = "Not bad. Try to include: " + tips.join(", ");
  qs("#promptFeedback").textContent = fb;
  // tiny grammar nudge
  if(/naitwa/i.test(text) && !/jina langu/i.test(text)){
    qs("#promptFeedback").textContent += " • Tip: You can also say “Jina langu ni ...”";
  }
  // record as seen
  state.stats.seen += 1; saveState(); renderStats(); drawHistory();
}

function renderStats(){
  qs("#statSeen").textContent = state.stats.seen||0;
  qs("#statMastered").textContent = state.stats.mastered||0;
  qs("#statStreak").textContent = state.streak||0;
}

function drawHistory(){
  const canvas = qs("#historyChart");
  if(!canvas) return;
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0,0,canvas.width,canvas.height);
  const padding = 30;
  const w = canvas.width - padding*2;
  const h = canvas.height - padding*2;
  const days = [...state.history].slice(-14); // last 14 days
  const maxSeen = Math.max(5, ...days.map(d=>d.seen));
  // axes
  ctx.globalAlpha = 1;
  ctx.strokeStyle = "rgba(255,255,255,.2)";
  ctx.beginPath();
  ctx.moveTo(padding, padding);
  ctx.lineTo(padding, padding+h);
  ctx.lineTo(padding+w, padding+h);
  ctx.stroke();
  // bars
  days.forEach((d,i)=>{
    const x = padding + i*(w/(Math.max(days.length,1))) + 6;
    const barW = (w/Math.max(days.length,1)) - 12;
    const barH = (d.seen/maxSeen)*h;
    ctx.fillStyle = "#6aa8ff";
    ctx.fillRect(x, padding + h - barH, barW, barH);
  });
}

function exportDeck(){
  const data = JSON.stringify(state.decks, null, 2);
  const blob = new Blob([data], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "kiswahili_decks.json";
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(url), 500);
}

function importDeck(file){
  const reader = new FileReader();
  reader.onload = ()=>{
    try{
      const data = JSON.parse(reader.result);
      if(typeof data === "object" && Object.keys(data).length){
        state.decks = data; saveState(); ensureDeckSelection(); initFlashcards();
        alert("Imported decks successfully.");
      } else { alert("Invalid deck file."); }
    }catch(e){ alert("Invalid JSON."); }
  };
  reader.readAsText(file);
}

function addTerm(sw, en, ex){
  const name = qs("#deckSelect").value;
  state.decks[name].push({sw,en,ex});
  saveState();
  initFlashcards();
}

function initTheme(){
  document.documentElement.classList.toggle("light", state.theme==="light");
}

function toggleTheme(){
  state.theme = state.theme==="light" ? "dark" : "light";
  saveState();
  initTheme();
}

// Wiring UI
document.addEventListener("DOMContentLoaded", ()=>{
  loadState();
  ensureDeckSelection();
  initTheme();
  initFlashcards();
  initPrompts();
  renderStats(); drawHistory();

  // Tabs
  qsa(".tab").forEach(tab=>{
    tab.addEventListener("click", ()=>{
      qsa(".tab").forEach(t=>t.classList.remove("active"));
      qsa(".panel").forEach(p=>p.classList.remove("active"));
      tab.classList.add("active");
      qs("#"+tab.dataset.tab).classList.add("active");
      if(tab.dataset.tab==="matching") initMatching();
      if(tab.dataset.tab==="progress") drawHistory();
    });
  });

  // Flashcard interactions
  const card = qs("#flashcard");
  card.addEventListener("click", ()=>{
    card.classList.toggle("flipped");
    fcFlipped = !fcFlipped;
  });
  qs("#goodBtn").addEventListener("click", ()=>markAnswer(true));
  qs("#againBtn").addEventListener("click", ()=>markAnswer(false));
  qs("#speakBtn").addEventListener("click", ()=>{
    const item = currentDeck[fcIndex % currentDeck.length];
    speakSwahili(item.sw);
  });

  qs("#deckSelect").addEventListener("change", ()=>{
    initFlashcards(); initMatching();
  });

  // Matching
  qs("#newMatch").addEventListener("click", initMatching);

  // Prompts
  qs("#newPrompt").addEventListener("click", shufflePrompt);
  qs("#checkPrompt").addEventListener("click", checkPrompt);

  // Add term dialog
  const dlg = qs("#addDialog");
  qs("#addTermBtn").addEventListener("click", ()=>dlg.showModal());
  qs("#addForm").addEventListener("submit", e=>{
    e.preventDefault();
  });
  dlg.addEventListener("close", ()=>{
    if(dlg.returnValue === "confirm"){
      const sw = qs("#swInput").value.trim();
      const en = qs("#enInput").value.trim();
      const ex = qs("#exInput").value.trim();
      if(sw && en) addTerm(sw,en,ex);
      qs("#swInput").value=""; qs("#enInput").value=""; qs("#exInput").value="";
    }
  });

  // Progress
  qs("#exportBtn").addEventListener("click", exportDeck);
  qs("#importBtn").addEventListener("click", ()=>qs("#importInput").click());
  qs("#importInput").addEventListener("change", e=>{
    const f = e.target.files?.[0]; if(f) importDeck(f);
  });

  // Theme
  qs("#themeToggle").addEventListener("click", toggleTheme);

  // Accessibility: enter to flip
  card.addEventListener("keydown", (e)=>{ if(e.key==="Enter"||e.key===" "){ e.preventDefault(); card.click(); }});
});
